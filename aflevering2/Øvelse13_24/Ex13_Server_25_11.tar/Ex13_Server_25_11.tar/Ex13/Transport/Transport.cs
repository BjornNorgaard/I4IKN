using System;
using Linklaget;
using System.Threading;

/// <summary>
/// Transport.
/// </summary>
namespace Transportlaget
{
	/// <summary>
	/// Transport.
	/// </summary>
	public class Transport
	{
		/// <summary>
		/// The link.
		/// </summary>
		private Link link;
		/// <summary>
		/// The 1' complements checksum.
		/// </summary>
		private Checksum checksum;
		/// <summary>
		/// The buffer.
		/// </summary>
		private byte[] buffer;
		/// <summary>
		/// The seq no.
		/// </summary>
		private byte seqNo;
		/// <summary>
		/// The old_seq no.
		/// </summary>
		private byte old_seqNo;
		/// <summary>
		/// The error count.
		/// </summary>
		private int errorCount;
		/// <summary>
		/// The DEFAULT_SEQNO.
		/// </summary>
		private const int DEFAULT_SEQNO = 2;

		private const int HEADER_SIZE = 4;

		private int TRANSBUFSIZE;

		/// <summary>
		/// Initializes a new instance of the <see cref="Transport"/> class.
		/// </summary>
		public Transport (int BUFSIZE)
		{
			link = new Link(BUFSIZE + HEADER_SIZE);
			checksum = new Checksum();
			TRANSBUFSIZE = BUFSIZE;
			buffer = new byte[TRANSBUFSIZE + HEADER_SIZE];
			seqNo = 0;
			old_seqNo = DEFAULT_SEQNO;
			errorCount = 0;
		}

		public void sendText(string textToSend)
		{
			System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding ();
			send (encoding.GetBytes (textToSend), textToSend.Length);
		}

		public string readText()
		{
			byte[] stringBuffer = new byte[TRANSBUFSIZE];
			System.Text.UTF8Encoding  encoding=new System.Text.UTF8Encoding();
			int bytesReceived = receive (ref stringBuffer);
			return encoding.GetString (stringBuffer, 0, bytesReceived);
		}

		/// <summary>
		/// Receives the ack.
		/// </summary>
		/// <returns>
		/// The ack.
		/// </returns>
		private bool receiveAck()
		{
			byte[] buf = new byte[(int)TransSize.ACKSIZE];
			int size = link.receive(ref buf);
			if (size != (int)TransSize.ACKSIZE) return false;
			if(!checksum.checkChecksum(buf, (int)TransSize.ACKSIZE) ||
					buf[(int)TransCHKSUM.SEQNO] != seqNo ||
					buf[(int)TransCHKSUM.TYPE] != (int)TransType.ACK)
				return false;

			seqNo = (byte)((buf[(int)TransCHKSUM.SEQNO] + 1) % 2);
						
			return true;
		}

		/// <summary>
		/// Sends the ack.
		/// </summary>
		/// <param name='ackType'>
		/// Ack type.
		/// </param>
		private void sendAck (bool ackType)
		{
			byte[] ackBuf = new byte[(int)TransSize.ACKSIZE];
			ackBuf [(int)TransCHKSUM.SEQNO] = (byte)
				(ackType ? (byte)(buffer  [(int)TransCHKSUM.SEQNO]) : ((byte)buffer [(int)TransCHKSUM.SEQNO] + 1) % 2);
			ackBuf [(int)TransCHKSUM.TYPE] = (byte)(int)TransType.ACK;
			checksum.calcChecksum (ref ackBuf, (int)TransSize.ACKSIZE);

			link.send(ackBuf, (int)TransSize.ACKSIZE);
		}

		/// <summary>
		/// Send the specified buffer and size.
		/// </summary>
		/// <param name='buffer'>
		/// Buffer.
		/// </param>
		/// <param name='size'>
		/// Size.
		/// </param>
		public void send(byte[] buf, int size)
		{
			buffer [0] = 0; //checksum high - replaces in calcChecksum
			buffer [1] = 0; //checksum low - replaces in calcChecksum
			buffer [2] = seqNo; //seq number
			buffer [3] = 0; //Type (0 = data / 1 = ack)
			Array.Copy(buf, 0, buffer, HEADER_SIZE, buf.Length);

			checksum.calcChecksum (ref buffer, size + HEADER_SIZE); //insert checksum

			bool ackReceived = false;
			//[TEST]Console.WriteLine (buffer [0] + ", " + buffer [1] + ", " + buffer.Length + ", " + (size+4));

			do {
				link.send (buffer, size + HEADER_SIZE);

				ackReceived = receiveAck ();
			} while (!ackReceived);

		}

		/// <summary>
		/// Receive the specified buffer.
		/// </summary>
		/// <param name='buffer'>
		/// Buffer.
		/// </param>
		public int receive (ref byte[] buf)
		{
			int receivedBytes = 0;
			bool receivedOk = false;
			do 
			{
				receivedBytes = link.receive (ref buffer);
				receivedOk = checksum.checkChecksum (buffer, receivedBytes);
				sendAck (receivedOk);
				Array.Copy(buffer, HEADER_SIZE, buf, 0, buf.Length);
			} while(!receivedOk);
			return receivedBytes - HEADER_SIZE;
		}
	}
}

